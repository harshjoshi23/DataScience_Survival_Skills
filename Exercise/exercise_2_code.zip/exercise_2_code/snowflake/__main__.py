from . import let_it_snow

let_it_snow.main()
