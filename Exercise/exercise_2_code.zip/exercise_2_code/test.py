import snowflake

snowflake.let_it_snow.main(3, "red")
